$( document ).ready(function() {
  "use strict";
  function game2(set2){   

    let question2 = {
        "instruction": "Listen to what the rabbit says and choose the correct egg.",
        "questions": [
          {
              "ques_word":"underage",
              "ques_aud":"./assets/set2/Q_underage.mp3",
              "hint_aud":"./assets/set2/H_underage.mp3",
              "ques_pic1":"./assets/set2/oldman.jfif",
              "ques_pic2":"./assets/set2/underage.jpg",
              "answer1": "oldman",
              "answer2": "underage"
          } ,
          {
              "ques_word":"undercooked",
              "ques_aud":"./assets/set2/Q_undercooked.mp3",
              "hint_aud":"./assets/set2/H_undercooked.mp3",
              "ques_pic1":"./assets/set2/cooked.jfif",
              "ques_pic2":"./assets/set2/undercooked.jfif",
              "answer1": "cooked",
              "answer2": "undercooked"
          },
          {
              "ques_word":"underground",
              "ques_aud":"./assets/set2/Q_underground.mp3",
              "hint_aud":"./assets/set2/H_underground.mp3",
              "ques_pic1":"./assets/set2/train.jfif",
              "ques_pic2":"./assets/set2/underground.jfif",
              "answer1": "train",
              "answer2": "underground"
          },
          {
              "ques_word":"underline",
              "ques_aud":"./assets/set2/Q_underline.mp3",
              "hint_aud":"./assets/set2/H_underline.mp3",
              "ques_pic1":"./assets/set2/underline.png",
              "ques_pic2":"./assets/set2/crossed.png",
              "answer1": "underline",
              "answer2": "crossed"
          },
          {
              "ques_word":"underpaid",
              "ques_aud":"./assets/set2/Q_underpaid.mp3",
              "hint_aud":"./assets/set2/H_underpaid.mp3",
              "ques_pic1":"./assets/set2/underpaid.jfif",
              "ques_pic2":"./assets/set2/overpaid.jfif",
              "answer1": "underpaid",
              "answer2": "overpaid"
          },
          {
              "ques_word":"undersize",
              "ques_aud":"./assets/set2/Q_undersize.mp3",
              "hint_aud":"./assets/set2/H_undersize.mp3",
              "ques_pic1":"./assets/set2/undersize.jfif",
              "ques_pic2":"./assets/set2/oversize.jfif",
              "answer1": "undersize",
              "answer2": "oversize"
          },
          {
              "ques_word":"underused",
              "ques_aud":"./assets/set2/Q_underused.mp3",
              "hint_aud":"./assets/set2/H_underused.mp3",
              "ques_pic1":"./assets/set2/underused.jfif",
              "ques_pic2":"./assets/set2/overuse.jfif",
              "answer1": "underused",
              "answer2": "overuse"
          },
          {
              "ques_word":"underwater",
              "ques_aud":"./assets/set2/Q_underwater.mp3",
              "hint_aud":"./assets/set2/H_underwater.mp3",
              "ques_pic1":"./assets/set2/overwater.jfif",
              "ques_pic2":"./assets/set2/underwater.jfif",
              "answer1": "overwater",
              "answer2": "underwater"
          },
          {
              "ques_word":"underwear",
              "ques_aud":"./assets/set2/Q_underwear.mp3",
              "hint_aud":"./assets/set2/H_underwear.mp3",
              "ques_pic1":"./assets/set2/jacket.jfif",
              "ques_pic2":"./assets/set2/underwear.jfif",
              "answer1": "jacket",
              "answer2": "underwear"
          },
          {
              "ques_word":"underweight",
              "ques_aud":"./assets/set2/Q_underweight.mp3",
              "hint_aud":"./assets/set2/H_underweight.mp3",
              "ques_pic1":"./assets/set2/underweight.jfif",
              "ques_pic2":"./assets/set2/overweight.jfif",
              "answer1": "underweight",
              "answer2": "overweight"
          }
        ]
    };
        // console.log(question2.questions[1].type);

    /************ rolling dice **********/
    let step = 0;
    let curPos = 0; //means start position
    let cntStep = 12; // number of steps

    let proNo;
    let suc = 0;         // count of success
    let failure = 0;     // count of failure
    let cheer_aud = new Audio("./assets/audio/cheerful.ogg");
    let completion_aud = new Audio("./assets/audio/completion.ogg");

    function rollDice() {
      const dice = [...document.querySelectorAll(".die-list")];
      dice.forEach(die => {
        toggleClasses(die);
        step = getRandomNumber(1, 6);  
        die.dataset.roll = step;
      });
      setTimeout(moveCat ,2000 , step);

    }

    function toggleClasses(die) {
      die.classList.toggle("odd-roll");
      die.classList.toggle("even-roll");
    }

    function getRandomNumber(min, max) {
      min = Math.ceil(min);
      max = Math.floor(max);
      return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // function endGame(){

    // }
    document.getElementById("dice").addEventListener("click", rollDice);
    // document.getElementById("end-btn").addEventListenner("click", endGame);
    /***********exchanging rows************/
    function exchangeProblems(){
      let i;
      for(i = 0 ; i < cntStep - 2; i++){
          let num = getRandomNumber(1,cntStep - 3);
          let tempPro = question2.questions[0];
          question2.questions[0] = question2.questions[num];
          question2.questions[num] = tempPro;
      }

    }

    exchangeProblems();
    /***********moving cat************/

      var ques_pos = new Array(cntStep);
      var h = $(".gameboard").css("height");
      var headerH = $(".header-section").css("height");
      console.log("headerH = ", headerH);
      var tempH = parseInt(headerH.replace(/px/,""));
      //initialize the positions of questions.
      for(let i = 0 ; i < cntStep ; i++){
        let  left = $(".item" + (i+1)).css("left");
        let top = $(".item" + (i+1)).css("top");
        var tempT = parseInt(top.replace(/px/,""));
        ques_pos[i] = { "left":left, "top": (tempH + tempT)+"px" };

        //insert content
      }

      console.log("ques_pos = ", ques_pos);

      document.getElementById("game-area").setAttribute("width","600px");
      document.getElementById("game-area").setAttribute("height",h);
      document.getElementById("game-area").style.position = "absolute";

      var canvas = new fabric.Canvas("game-area");
      // canvas.setHeight(h);
      // canvas.renderAll();
      //add cat to screen
      var catImg = document.getElementById('cat-img');
      var catInstance = new fabric.Image(catImg, {left:300,top:10, opacity:1});//scaleX:0.2,scaleY:0.2,
      // var catInstance = new fabric.Image(catImg, {left:100,top:100,angle:30,opacity:0.85});
      canvas.add(catInstance);

      function moveCat(pos){
         let ll,tt;
         curPos += pos;     

         if(curPos >= (cntStep-1)){
            // moveCat(cntStep-1);
             ll =  parseInt(ques_pos[cntStep - 1].left.replace(/px/,""));
             tt = parseInt(ques_pos[cntStep - 1].top.replace(/px/,"")); 
             catInstance.set({left:ll,top:tt-80, opacity:1});
             canvas.renderAll(); 
             console.log("success = " + suc + " failure = " + failure);
             completion_aud.play();
             alert("ended");
             return;      
         }else{

            // catInstance.set("top","100px");
             ll =  parseInt(ques_pos[curPos].left.replace(/px/,""));
             tt = parseInt(ques_pos[curPos].top.replace(/px/,""));
             console.log("ll = " + ll + " tt = " + tt);
             catInstance.set({left:ll,top:tt-80, opacity:1});
             canvas.renderAll();
             cheer_aud.play();
             if(curPos >= 1){          
                setTimeout(showProblem, 1000, curPos - 1);
                // setTimeout(showProblem, 1000, 2);
             }
         }

         //move the cat on the other layers
         // document.getElementById('game-area').style.zIndex = 200;
      }
      
      function showProblem(proIndex){
          let modal = document.getElementById("ques-Modal");
          proNo = proIndex;      

          modal.style.display = "block";
          document.getElementsByClassName("header-section")[0].style.zIndex = 50;
          $(".modal-content").html("<h1 id='caption'></h1><div class='modal-content-img-a'><img class='b-ques-pic01' id='b-ques-pic01'><img class='b-ques-pic02' id='b-ques-pic02'></div>");
          let ques_pic01 = document.getElementById("b-ques-pic01");
          let ques_pic02 = document.getElementById("b-ques-pic02");
          let captionText = document.getElementById("caption");

          ques_pic01.src = question2.questions[proIndex].ques_pic1;
          ques_pic02.src = question2.questions[proIndex].ques_pic2;
          captionText.innerHTML = "Which picture means <span style='text-decoration:underline;'>" + question2.questions[proIndex].ques_word +"</span>?";
          let suc_aud = new Audio("./assets/set2/well done.mp3");
          let hint_aud = new Audio(question2.questions[proIndex].hint_aud);
          let ques_aud = new Audio(question2.questions[proIndex].ques_aud);
          ques_aud.play();
          $("#b-ques-pic01").click(function(e){
              let answer = question2.questions[proIndex].answer1;
              console.log("b your answer = ",answer)
              console.log("b correct answer = ", question2.questions[proIndex].ques_word);
              if(answer == question2.questions[proIndex].ques_word){
                suc++; cheer_aud.play();setTimeout(() => suc_aud.play(), 2000)
              }
              else{
                failure++; hint_aud.play();return;
              }
              modal.style.display = "none";
              console.log("suc = " + suc + " failure = " + failure); 
              document.getElementsByClassName("header-section")[0].style.zIndex = 150;
              return;
          });
          $("#b-ques-pic02").click(function(e){
              let answer = question2.questions[proIndex].answer2;
              console.log("b your answer = ",answer)
              console.log("b correct answer = ", question2.questions[proIndex].ques_word);
              if(answer == question2.questions[proIndex].ques_word){
                suc++; cheer_aud.play();setTimeout(() => suc_aud.play(), 2000)
              }
              else{
                failure++; hint_aud.play(); return;
              }
              modal.style.display = "none";
              console.log("suc = " + suc + " failure = " + failure); 
              document.getElementsByClassName("header-section")[0].style.zIndex = 150;
              return;
          });     
       
      }      
      
     
      moveCat(0); //move the cat to start position.
  }
  game2();
});

