$( document ).ready(function() {
  "use strict";
  function game3(set3){   

    let question3 = {
        "instruction": "Listen to what the rabbit says and choose the correct egg.",
        "questions": [
          {
              "handbag":{"aud":"./assets/set3/handbag.mp3","img": "./assets/img/handbag.png"},
              "headache":{"aud":"./assets/set3/headache.mp3","img": "./assets/img/headache.png"},
              "necklace":{"aud":"./assets/set3/necklace.mp3","img": "./assets/img/necklace.png"},
              "waterfall":{"aud":"./assets/set3/waterfall.mp3","img": "./assets/img/waterfall.png"}
          },
          {
              "handbag":{"aud":"./assets/set3/handbag.mp3","img": "./assets/img/handbag.png"},
              "headache":{"aud":"./assets/set3/headache.mp3","img": "./assets/img/headache.png"},
              "necklace":{"aud":"./assets/set3/necklace.mp3","img": "./assets/img/necklace.png"},
              "waterfall":{"aud":"./assets/set3/waterfall.mp3","img": "./assets/img/waterfall.png"}
          },
          {
              "handbag":{"aud":"./assets/set3/handbag.mp3","img": "./assets/img/handbag.png"},
              "headache":{"aud":"./assets/set3/headache.mp3","img": "./assets/img/headache.png"},
              "necklace":{"aud":"./assets/set3/necklace.mp3","img": "./assets/img/necklace.png"},
              "waterfall":{"aud":"./assets/set3/waterfall.mp3","img": "./assets/img/waterfall.png"}
          },
          {
              "handbag":{"aud":"./assets/set3/handbag.mp3","img": "./assets/img/handbag.png"},
              "headache":{"aud":"./assets/set3/headache.mp3","img": "./assets/img/headache.png"},
              "necklace":{"aud":"./assets/set3/necklace.mp3","img": "./assets/img/necklace.png"},
              "waterfall":{"aud":"./assets/set3/waterfall.mp3","img": "./assets/img/waterfall.png"}
          },
        ]
    };
   
      /************ rolling dice **********/
     
      let curPos = 0; //means start position
      let cntPro = question3.questions.length; // number of steps

      let proNum;
      let suc = 0;         // count of success
      let failure = 0;     // count of failure
      let cheer_aud = new Audio("./assets/audio/cheerful.ogg");
      let completion_aud = new Audio("./assets/audio/completion.ogg");
      let instruction_aud = new Audio("./assets/set3/instruction.mp3");
      let suc_aud = new Audio("./assets/audio/well done.mp3");
      let fail_aud = new Audio("./assets/audio/wrong.ogg");
      let cur_answer = "";
      let key1,key2,key3,key4;
      // instruction_aud.play();
      let pro_flag = 0, rab_flag = 0;
      let result_img = document.getElementById("result-img");

      function getRandomNumber(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
      }

      // document.getElementById("end-btn").addEventListenner("click", endGame);
      /***********exchanging rows************/
      function exchangeProblems(){
        let i;
        for(i = 0 ; i < cntPro - 2; i++){
            let num = getRandomNumber(1,cntPro-1);
            let tempPro = question3.questions[0];
            question3.questions[0] = question3.questions[num];
            question3.questions[num] = tempPro;
        }
        for(i = 0 ; i < cntPro ; i++){
            let keys = Object.keys(question3.questions[i]);
            let values = Object.values(question3.questions[i]);
           
            for(let p = 0 ; p < 4 ; p++){
                let r = getRandomNumber(0,3);
                let itemKey = keys[0];
                let itemValue = values[0];
                keys[0] = keys[r];
                values[0] = values[r];
                keys[r] = itemKey;
                values[r] = itemValue;
            }
            let obj = {};
            for(let p = 0 ; p < 4 ; p++)
              obj[keys[p]] = values[p];

            //save the exchanged items of nth problem
            question3.questions[i] = obj;
        }

      }
      exchangeProblems();
      console.log("problems = ", question3);
      showProblems();

      function showProblems(){
        if(curPos >= cntPro)
        {
          completion_aud.play();
          alert("completed");
          return;
        }
        
        let ques_pic01 = document.getElementById("pro3-1-img");
        let ques_pic02 = document.getElementById("pro3-2-img");
        let ques_pic03 = document.getElementById("pro3-3-img");
        let ques_pic04 = document.getElementById("pro3-4-img");
        ques_pic01.src = Object.values( question3.questions[curPos] )[0].img;
        key1 = Object.keys(question3.questions[curPos])[0];
        ques_pic02.src = Object.values( question3.questions[curPos] )[1].img;
        key2 = Object.keys(question3.questions[curPos])[1];
        ques_pic03.src = Object.values( question3.questions[curPos] )[2].img;
        key3 = Object.keys(question3.questions[curPos])[2];
        ques_pic04.src = Object.values( question3.questions[curPos] )[3].img;
        key4 = Object.keys(question3.questions[curPos])[3];
        $("#pro3-1-question").html(key1);
        $("#pro3-2-question").html(key2);
        $("#pro3-3-question").html(key3);
        $("#pro3-4-question").html(key4);

        pro_flag = 1;
        proNum = getRandomNumber(0 , 3);
      }   

      $(".rabbit-img").click(function(){          
          if(pro_flag === 1){
            pro_flag = 0;
            rab_flag = 1;
          }
          else{
            return false;
          }
        cur_answer = Object.keys(question3.questions[curPos])[proNum];
        let cur_aud_url = Object.values(question3.questions[curPos])[proNum].aud;
        let cur_audio = new Audio(cur_aud_url);
        cur_audio.play();     

      });
      $("#egg1").click(function(e){
          if(rab_flag === 1){
            rab_flag = 0;
          }
          else{
            return false;
          }
          console.log(" answer = ",cur_answer);
          if(cur_answer == key1){
            suc++; cheer_aud.play();setTimeout(() => suc_aud.play(), 2000)
            curPos++;
            result_img.src = "./assets/img/welldone.png";
            mask("#egg1");
          }
          else{
            failure++; fail_aud.play();
            result_img.src = "./assets/img/wrong.png";
            pro_flag = 1; 
          }
          console.log("suc = " + suc + " failure = " + failure); 
          
          return;
      });
      $("#egg2").click(function(e){
          if(rab_flag === 1){
            rab_flag = 0;
          }
          else{
            return false;
          }
          
          console.log(" answer = ",cur_answer);
          if(cur_answer == key2){
            suc++; cheer_aud.play();setTimeout(() => suc_aud.play(), 2000)
            curPos++;
            result_img.src = "./assets/img/welldone.png";
            mask("#egg2");
          }
          else{
            failure++; fail_aud.play();
            result_img.src = "./assets/img/wrong.png";
            pro_flag = 1; 
          }
          console.log("suc = " + suc + " failure = " + failure); 
          
          return;
      });
      $("#egg3").click(function(e){
          if(rab_flag === 1){
            rab_flag = 0;
          }
          else{
            return false;
          }
          console.log(" answer = ",cur_answer);
          if(cur_answer == key3){
            suc++; cheer_aud.play();setTimeout(() => suc_aud.play(), 2000)
            curPos++;
            result_img.src = "./assets/img/welldone.png";
            mask("#egg3");
          }
          else{
            failure++; fail_aud.play();
            result_img.src = "./assets/img/wrong.png";            
            pro_flag = 1; 
          }
          console.log("suc = " + suc + " failure = " + failure); 
          
          return;
      });
      $("#egg4").click(function(e){
          if(rab_flag === 1){
            rab_flag = 0;
          }
          else{
            return false;
          }
          console.log(" answer = ",cur_answer);
          
          if(cur_answer == key4){
            suc++; cheer_aud.play();setTimeout(() => suc_aud.play(), 2000)
            curPos++;
            result_img.src = "./assets/img/welldone.png";
            mask("#egg4");
          }
          else{
            failure++; fail_aud.play();
            result_img.src = "./assets/img/wrong.png";
            pro_flag = 1; 
          }
          console.log("suc = " + suc + " failure = " + failure); 
          
          return;
      });

      function mask(eggid){
          $(eggid).css("z-index", 50);
          $("#mask").css("z-index",30);
          $("#mask").css("background-color","rgba(47,46,45,0.8)");
          $("body").css("background-color","rgba(47,46,45,0.8)");
          setTimeout(clearMask, 3000, eggid);
      }

      function clearMask(eggid){  
          $(eggid).css("z-index", 25);
          $("#mask").css("z-index",10);
          $("#mask").css("background-color","rgba(0,0,255,0.05");
          $("body").css("background-color", "#ffffff");
          // $(".gameboard").css("background-color","rgba(0,0,255,0.1)");
          result_img.src ="";
          showProblems();
      }
  }


  game3();

});

